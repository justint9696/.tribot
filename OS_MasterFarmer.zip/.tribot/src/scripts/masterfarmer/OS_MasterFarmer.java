package scripts.masterfarmer;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;

import scripts.masterfarmer.nodes.*;
import scripts.masterfarmer.utils.Node;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api2007.Skills;
import org.tribot.api2007.Skills.SKILLS;
import org.tribot.script.Script;
import org.tribot.script.ScriptManifest;
import org.tribot.script.interfaces.MousePainting;
import org.tribot.script.interfaces.Painting;

@ScriptManifest(authors = { "MaxedNinja123" }, category = "Thieving", name = "OS Master Farmer")
public class OS_MasterFarmer extends Script implements Painting, MousePainting {

	public ArrayList<Node> nodes = new ArrayList<Node>();
	public int startExp = Skills.getXP(SKILLS.THIEVING);
	public int startLevel = Skills.getCurrentLevel(SKILLS.THIEVING);
	public long startTime = System.currentTimeMillis();

	@Override
	public void run() {
		if (onStart()) {
			while (true) {
				for (Node node : nodes) {
					if (node.validate()) {
						node.execute();
					}
				}
				sleep(100);
			}
		}
	}

	public boolean onStart() {
		nodes.add(new Antiban());
		nodes.add(new Bank());
		nodes.add(new Drop());
		nodes.add(new Heal());
		nodes.add(new Pickpocket());
		nodes.add(new WalkToBank());
		nodes.add(new WalkToFarmer());
		Mouse.setSpeed(General.random(115, 125));
		return true;
	}

	@Override
	public void onPaint(Graphics g) {
		long timeRan = System.currentTimeMillis() - startTime;
		double multiplier = getRunningTime() / 3600000.0D;
		int expPerHour = (int) ((Skills.getXP(SKILLS.THIEVING) - startExp) / multiplier);
		int gainedLevels = Skills.getCurrentLevel(SKILLS.THIEVING) - startLevel;

		g.setColor(new Color(0, 0, 0, .8f));
		g.drawRect(5, 345, 505, 130);
		g.fillRect(5, 345, 505, 130);

		Font font = new Font("Verdana", Font.BOLD, 14);
		g.setFont(font);

		g.setColor(Color.WHITE);
		g.drawString("OS Master Farmer", 15, 365);
		g.drawString("Runtime: " + Timing.msToString(System.currentTimeMillis() - startTime), 15, 395);
		g.drawString("XP Gained: " + (Skills.getXP(SKILLS.THIEVING) - startExp) + " (" + expPerHour + "/hr)", 15, 410);
		g.drawString("Level: " + Skills.getCurrentLevel(SKILLS.THIEVING) + " (Gained: " + gainedLevels + ")", 15, 425);
	}

	@Override
	public void paintMouse(Graphics arg0, Point arg1, Point arg2) {
		Graphics2D g = (Graphics2D) arg0;
		int x, y;
		x = (int) Mouse.getPos().getX();
		y = (int) Mouse.getPos().getY();
		g.setColor(Color.WHITE);
		g.drawLine(x - 5, y, x + 5, y);
		g.drawLine(x, y - 5, x, y + 5);
	}

}
