package scripts.masterfarmer.nodes;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.util.ABCUtil;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Login;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSItem;

import scripts.masterfarmer.utils.Node;

public class Bank implements Node {

	public ABCUtil ABCUtil = new ABCUtil();

	@Override
	public boolean validate() {
		return !hasFood() && Banking.isInBank();
	}

	@Override
	public void execute() {
		if (!Banking.isBankScreenOpen())
			Banking.openBank();

		RSItem[] food = Banking.find("Tuna");
		if (food.length > 0) {
			if (Banking.withdraw(14, food[0].getID())) {
				if (Timing.waitCondition(() -> Inventory.find(Filters.Items.actionsContains("Eat")).length > 0, 6000)) {
					Timing.waitCondition(() -> performHumanActions(), 6000);
				}
			}
		}

		Banking.close();
	}

	public boolean hasFood() {
		return Inventory.find(Filters.Items.actionsContains("Eat")).length > 0;
	}

	public boolean performHumanActions() {
		ABCUtil.performExamineObject();
		ABCUtil.performRandomMouseMovement();
		ABCUtil.performRandomRightClick();
		return true;
	}

}
