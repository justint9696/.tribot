package scripts.masterfarmer.nodes;

import org.tribot.api2007.Banking;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Walking;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSTile;

import scripts.masterfarmer.utils.Node;

public class WalkToBank implements Node {

	public RSTile[] BANK_PATH = { new RSTile(3082, 3250, 0), new RSTile(3090, 3250, 0), new RSTile(3093, 3243, 0) };

	@Override
	public boolean validate() {
		return !hasFood() && !Banking.isInBank();
	}

	@Override
	public void execute() {
		Walking.walkPath(BANK_PATH);
	}

	public boolean hasFood() {
		return Inventory.find(Filters.Items.actionsContains("Eat")).length > 0;
	}

}
