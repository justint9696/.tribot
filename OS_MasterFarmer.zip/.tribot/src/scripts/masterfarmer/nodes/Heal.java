package scripts.masterfarmer.nodes;

import scripts.masterfarmer.utils.Node;

import org.tribot.api.Clicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.util.abc.ABCUtil;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Player;
import org.tribot.api2007.Skills;
import org.tribot.api2007.Skills.SKILLS;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSItem;

public class Heal implements Node {

	public ABCUtil ABCUtil = new ABCUtil();
	public int eatAt = ABCUtil.generateEatAtHP();

	@Override
	public boolean validate() {
		return Skills.getCurrentLevel(SKILLS.HITPOINTS) < eatAt;
	}

	@Override
	public void execute() {
		RSItem[] food = Inventory.find(Filters.Items.actionsContains("Eat"));
		if (food.length > 0) {
			if (Clicking.click("Eat", food[0])) {
				Timing.waitCondition(() -> Player.getAnimation() != -1, 6000);
				eatAt = ABCUtil.generateEatAtHP();
				General.println("[ABC2] Next eat at: " + eatAt);
			}
		}
	}

}
