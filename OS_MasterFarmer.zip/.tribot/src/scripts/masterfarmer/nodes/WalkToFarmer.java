package scripts.masterfarmer.nodes;

import org.tribot.api.Timing;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.NPCs;
import org.tribot.api2007.Player;
import org.tribot.api2007.Walking;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSNPC;
import org.tribot.api2007.types.RSTile;

import scripts.masterfarmer.utils.Node;

public class WalkToFarmer implements Node {

	public RSTile[] FAMER_PATH = { new RSTile(3089, 3249, 0), new RSTile(3080, 3250, 0) };

	@Override
	public boolean validate() {
		RSNPC[] farmer = NPCs.find("Master Farmer");
		if (farmer.length > 0) {
			return hasFood() && Player.getPosition().distanceTo(farmer[0]) > 10;
		}
		return false;
	}

	@Override
	public void execute() {
		RSNPC[] farmer = NPCs.find("Master Farmer");
		if (farmer.length > 0) {
			if (Timing.waitCondition(() -> Walking.walkPath(FAMER_PATH), 6000)) {
				Timing.waitCondition(() -> farmer[0].isOnScreen() || !Player.isMoving(), 6000);
			}
		}
	}

	public boolean hasFood() {
		return Inventory.find(Filters.Items.actionsContains("Eat")).length > 0;
	}
}
