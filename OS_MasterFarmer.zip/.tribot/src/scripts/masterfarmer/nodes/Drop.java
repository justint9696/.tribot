package scripts.masterfarmer.nodes;

import org.tribot.api2007.Inventory;
import org.tribot.api2007.Inventory.DROPPING_PATTERN;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSItem;

import scripts.masterfarmer.utils.Node;

public class Drop implements Node {

	@Override
	public boolean validate() {
		return !hasFood() || Inventory.isFull();
	}

	@Override
	public void execute() {
		Inventory.setDroppingPattern(DROPPING_PATTERN.TOP_TO_BOTTOM);
		RSItem[] seeds = Inventory.find(Filters.Items.nameContains(" seed"));
		Inventory.drop(seeds);
	}

	public boolean hasFood() {
		return Inventory.find(Filters.Items.actionsContains("Eat")).length > 0;
	}

}
