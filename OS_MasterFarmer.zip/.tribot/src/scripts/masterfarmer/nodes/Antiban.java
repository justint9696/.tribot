package scripts.masterfarmer.nodes;

import org.tribot.api.General;
import org.tribot.api.util.abc.ABCUtil;
import org.tribot.api2007.Player;

import scripts.masterfarmer.utils.Node;

public class Antiban implements Node {

	public ABCUtil ABCUtil = new ABCUtil();

	@Override
	public boolean validate() {
		return Player.getAnimation() == -1 && !Player.isMoving();
	}

	@Override
	public void execute() {
		if (this.ABCUtil.shouldCheckTabs()) {
			General.println("[ABC2] Checking tabs");
			this.ABCUtil.checkTabs();
		}
		if (this.ABCUtil.shouldCheckXP()) {
			General.println("[ABC2] Checking XP");
			this.ABCUtil.checkXP();
		}
		if (this.ABCUtil.shouldExamineEntity()) {
			General.println("[ABC2] Examining entity");
			this.ABCUtil.examineEntity();
		}
		if (this.ABCUtil.shouldMoveMouse()) {
			General.println("[ABC2] Moving mouse");
			this.ABCUtil.moveMouse();
		}
		if (this.ABCUtil.shouldPickupMouse()) {
			General.println("[ABC2] Picking up mouse");
			this.ABCUtil.pickupMouse();
		}
		if (this.ABCUtil.shouldRightClick()) {
			General.println("[ABC2] Right clicking");
			this.ABCUtil.rightClick();
		}
		if (this.ABCUtil.shouldRotateCamera()) {
			General.println("[ABC2] Rotating camera");
			this.ABCUtil.rotateCamera();
		}
		if (this.ABCUtil.shouldLeaveGame()) {
			General.println("[ABC2] Moving mouse off screen");
			this.ABCUtil.leaveGame();
		}
	}

}
