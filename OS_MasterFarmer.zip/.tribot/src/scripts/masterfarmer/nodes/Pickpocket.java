package scripts.masterfarmer.nodes;

import java.awt.Point;
import org.tribot.api.Clicking;
import org.tribot.api.DynamicClicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api.util.ABCUtil;
import org.tribot.api2007.Camera;
import org.tribot.api2007.ChooseOption;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.NPCs;
import org.tribot.api2007.Player;
import org.tribot.api2007.Walking;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.RSNPC;

import scripts.masterfarmer.utils.Node;

public class Pickpocket implements Node {

	public ABCUtil ABCUtil = new ABCUtil();
	public org.tribot.api.util.abc.ABCUtil ABC = new org.tribot.api.util.abc.ABCUtil();

	@Override
	public boolean validate() {
		RSNPC[] farmer = NPCs.find("Master Farmer");
		if (farmer.length > 0) {
			return hasFood() && Player.getPosition().distanceTo(farmer[0]) < 10;
		}
		return false;
	}

	@Override
	public void execute() {
		RSNPC[] farmer = NPCs.find("Master Farmer");
		if (Camera.getCameraAngle() < 90) {
			// Less misclicks
			Camera.setRotationMethod(Camera.ROTATION_METHOD.ONLY_KEYS);
			Camera.setCameraAngle(General.random(90, 100));
		}
		if (farmer.length > 0) {
			if (farmer[0].isClickable()) {
				if (ChooseOption.isOpen()) {
					if (ChooseOption.select("Pickpocket")) {
						if (Timing.waitCondition(() -> farmer[0].isInteractingWithMe(), 2000)) {
							// We are stunned; wait stun delay
							General.println("Oh dear, we've been stunned!");
							if (this.ABC.shouldOpenMenu()) {
								DynamicClicking.clickRSNPC(farmer[0], 3);
							}
							General.sleep(General.random(5000, 6000));
						} else {
							if (Timing.waitCondition(() -> performHumanActions() && Player.getAnimation() == -1,
									6000)) {
								General.sleep(500, 1500);
							}
						}
					}
				} else if (Clicking.click("Pickpocket", farmer)) {
					if (Timing.waitCondition(() -> farmer[0].isInteractingWithMe(), 2000)) {
						// We are stunned; wait stun delay
						General.println("Oh dear, we've been stunned!");
						if (this.ABC.shouldOpenMenu()) {
							if (DynamicClicking.clickRSNPC(farmer[0], 3)) {
								Point p = new Point((int) Mouse.getPos().getX(),
										(int) Mouse.getPos().getY() + General.random(25, 30));
								Mouse.move(p);
							}
						}
						General.sleep(General.random(5000, 6000));
					} else {
						if (Timing.waitCondition(() -> performHumanActions() && Player.getAnimation() == -1, 6000)) {
							General.sleep(500, 1500);
						}
					}
				}
			} else {
				Camera.setRotationMethod(Camera.ROTATION_METHOD.ONLY_MOUSE);
				Walking.blindWalkTo(farmer[0]);
				farmer[0].adjustCameraTo();
			}
		}
	}

	public boolean performHumanActions() {
		ABCUtil.performExamineObject();
		ABCUtil.performRandomMouseMovement();
		ABCUtil.performRandomRightClick();
		return true;
	}

	public boolean hasFood() {
		return Inventory.find(Filters.Items.actionsContains("Eat")).length > 0;
	}

}
