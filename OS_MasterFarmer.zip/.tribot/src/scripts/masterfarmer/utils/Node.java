package scripts.masterfarmer.utils;

public interface Node {

	public abstract boolean validate();

	public abstract void execute();
}
